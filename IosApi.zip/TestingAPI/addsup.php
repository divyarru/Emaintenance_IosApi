<?php
// Set the appropriate content type for JSON
header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Establish a database connection
    $conn = mysqli_connect("localhost", "root", "", "maintanence");

    // Check if the connection was successful
    if (!$conn) {
        // If the connection fails, return an error response
        echo json_encode(['message' => 'Database connection failed']);
        exit; // Terminate the script
    }

    // Retrieve and sanitize data from the POST request
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $mobnum = mysqli_real_escape_string($conn, $_POST['mobnum']);

    // Check for empty values
    if (empty($role) || empty($name) || empty($mobnum)) {
        echo json_encode(['message' => 'All fields must be filled']);
        exit;
    }

    // SQL query to insert the employee into the database
    $sql = "INSERT INTO login (role, name, mobnum) 
            VALUES ('$role', '$name', '$mobnum')";

    // Execute the query
    if (mysqli_query($dbconn, $sql)) {
        // If the insertion is successful, return a success response
        echo json_encode(['message' => 'Employee added successfully']);
    } else {
        // If there's an error with the query, return an error response
        echo json_encode(['message' => 'Failed to add employee: ' . mysqli_error($conn)]);
    }

    // Close the database connection
    mysqli_close($dbconn);
} else {
    // If the request method is not POST, return a message indicating the invalid request method
    echo json_encode(['message' => 'Invalid request method']);
}
?>
