<?php
error_reporting(0);
require_once('dbconfig.php');

$allowedRoles = ['worker', 'supervisor'];

$loginqry = "SELECT * FROM login WHERE role IN ('" . implode("','", $allowedRoles) . "')";


$qry = mysqli_query($dbconn, $loginqry);

$response = array();

if (mysqli_num_rows($qry) > 0) {
    $i = 0;
    $student = array(); // Initialize an array to store the data

    while ($row = mysqli_fetch_assoc($qry)) {
        $student[$i]['name'] = $row['name'];
        $student[$i]['role'] = $row['role'];
        $student[$i]['mobnum'] = $row['mobnum'];
        $student[$i]['action'] = $row['action'];

        $i = $i + 1;
    }

    $response['status'] = true;
    $response['message'] = "Data Found";
    $response['data'] = $student;
} else {
    $response['status'] = false;
    $response['message'] = "No Data Found";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
