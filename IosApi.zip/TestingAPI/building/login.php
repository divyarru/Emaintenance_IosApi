<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

$username	=$_POST['username'];
$password	=$_POST['password'];

//$bioid	=	10101; //$_POST['bioid'];
//$password	='pass123';	//$_POST['password'];

$loginqry = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";

//$loginqry = "SELECT * FROM users WHERE bioid = 10101 AND password ='pass123'";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$userObj = mysqli_fetch_assoc($qry);
	$response['status'] = true;
	$response['message']= " Login Successfully";
	$response['data'] = $userObj;	
}
else{
	$response['status'] = false;
	$response['message']= "Login Failed";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>