<?php
error_reporting(0);
require_once('dbconfig.php');

$role = "supervisor"; // Set the desired role here

$loginqry = "SELECT * FROM login WHERE role = '$role'";
$qry = mysqli_query($dbconn, $loginqry);

if (mysqli_num_rows($qry) > 0) {
    $student = array(); // Initialize an empty array

    while ($row = mysqli_fetch_assoc($qry)) {
        $student[] = array(
            'name' => $row['name'],
            'role' => $row['role'],
            'mobnum' => $row['mobnum']
        );
    }

    $response = array(
        'status' => true,
        'message' => 'Login Successfully',
        'data' => $student
    );
} else {
    $response = array(
        'status' => false,
        'message' => 'No Data'
    );
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
