<?php
$dbconn = mysqli_connect('localhost','root','','maintanence');
if($dbconn){
//echo "Connection Sccessfully";
}
else{
die ("Connection Failed" . mysqli_connect_error());
}
?>