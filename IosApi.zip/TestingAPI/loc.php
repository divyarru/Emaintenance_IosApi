<?php
error_reporting(0);
require_once('dbconfig.php');

$loginqry = "SELECT location.building, location.floor, location.room, eqdetails.eid
             FROM eqdetails
             LEFT JOIN location ON eqdetails.eid = location.eidd";

$qry = mysqli_query($dbconn, $loginqry);

$response = array();

if (mysqli_num_rows($qry) > 0) {
    $i = 0;
    $data = array(); // Initialize an array to store the data

    while ($row = mysqli_fetch_assoc($qry)) {
        $data[$i]['building'] = $row['building'];
        $data[$i]['floor'] = $row['floor'];
        $data[$i]['room'] = $row['room'];
        $data[$i]['eid'] = $row['eid'];
        $i++;
    }

    $response['status'] = true;
    $response['message'] = "Data Found";
    $response['data'] = $data;
} else {
    $response['status'] = false;
    $response['message'] = "No Data Found";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
