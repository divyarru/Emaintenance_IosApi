<?php
// Set the appropriate content type for JSON
header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Establish a database connection
    $conn = mysqli_connect("localhost", "root", "", "maintanence");

    if (!$conn) {
        // If the connection fails, return an error response
        echo json_encode(['message' => 'Database connection failed']);
    } else {
        // Retrieve and sanitize data from the POST request
        $servicetype = mysqli_real_escape_string($conn, $_POST['servicetype']);
        $date = mysqli_real_escape_string($conn, $_POST['date']);
        $equipment = mysqli_real_escape_string($conn, $_POST['equipment']);
        $location = mysqli_real_escape_string($conn, $_POST['location']);
        $name = mysqli_real_escape_string($conn, $_POST['name']);

        // SQL query to insert the employee into the database
        $sql = "INSERT INTO job (servicetype, date, equipment, location, name) 
        VALUES ('$servicetype', '$date', '$equipment', '$location', '$name')";


        // Execute the query
        if (mysqli_query($conn, $sql)) {
            // If the insertion is successful, return a success response
            echo json_encode(['message' => 'Work Assigned successfully']);
        } else {
            // If there's an error with the query, return an error response
            echo json_encode(['message' => 'Failed to Assign Work']);
        }

        // Close the database connection
        mysqli_close($conn);
    }
} else {
    // If the request method is not POST, return a message indicating the invalid request method
    echo json_encode(['message' => 'Invalid request method']);
}
?>